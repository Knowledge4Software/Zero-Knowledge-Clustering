Compile manuscript.tex with latexmk -pdf, or pdflatex/bibtex/pdflatex/pdflatex.
The manuscript uses an Elsevier elsarticle working format. Check the target journal guide before submission.
Author information and declarations are pending; this is a research draft.
Generated CSVs and manifests retain numerical provenance. Raw proof bundles are separate.
